# Real-World AI Agent Workflow Dataset

Records: 885

This package expands the earlier workflow dataset with real-world, multi-stage tasks ranging from small tasks to large projects.

Domains:
business, software, data/AI, research, education, content/marketing, operations, finance/admin, creative, personal productivity.

Training signals:
- task decomposition
- tool and website selection
- specialized agent selection
- dependencies
- previous-result propagation
- verification
- adaptive replanning
- failure recovery
- missing-input handling
- permission-aware behavior
- final validation

Files:
- real_world_workflows.jsonl
- real_world_workflow_steps.csv
- task_intent_pairs.jsonl
- adaptive_decision_examples.jsonl
- DATASET_SCHEMA.json
- README.md

Do not treat tool names as guaranteed execution capabilities. At runtime the agent should check whether a tool is available, authorized, appropriate, and current.
