# AI Agent Task → Workflow Dataset

This dataset is designed for training/testing an agent that converts a user task into a practical multi-step workflow.

Files:
- workflow_dataset.jsonl — one complete workflow per JSONL record.
- workflow_steps.csv — flattened step-level training data.
- DATASET_SCHEMA.json — field definitions and behavioral rules.

Important:
- Tool names are examples/targets, not guarantees that the agent can actually access those services.
- For real execution, the agent should verify tool availability, permissions, cost, and current capabilities before acting.
- The dataset intentionally includes adaptive failure behavior so the model learns to re-plan instead of assuming every step succeeds.
